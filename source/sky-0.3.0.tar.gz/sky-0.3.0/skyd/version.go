package skyd

const (
	Version = "0.3.0"
)
