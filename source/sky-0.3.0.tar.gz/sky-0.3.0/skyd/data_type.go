package skyd

const (
	FactorDataType  = "factor"
	StringDataType  = "string"
	IntegerDataType = "integer"
	FloatDataType   = "float"
	BooleanDataType = "boolean"
)
