#ifndef _sky_string_h
#define _sky_string_h

//==============================================================================
//
// Typedefs
//
//==============================================================================

typedef struct {
  int32_t length;
  char *data;
} sky_string;

#endif