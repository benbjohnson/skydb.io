# Sky -- Open Source Behavioral Database

## Contribute

If you'd like to contribute to Sky, please fork the repo on GitHub:

https://github.com/skydb/sky

You're also welcome to discuss the project on the mailing list by sending an
e-mail to [sky@librelist.com](mailto:sky@librelist.com).
