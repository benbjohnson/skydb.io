#ifndef _sky_constants_h
#define _sky_constants_h

//==============================================================================
//
// Functions
//
//==============================================================================

//--------------------------------------
// Paths
//--------------------------------------

#define SKY_LIB_PATH       "lib"
#define SKY_LIB_CORE_PATH  SKY_LIB_PATH "/" "core"
#define SKY_LIB_SKY_PATH   SKY_LIB_PATH "/" "sky"


#endif