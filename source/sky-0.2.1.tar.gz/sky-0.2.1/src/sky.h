#ifndef _sky_h
#define _sky_h

#include "server.h"

#endif
