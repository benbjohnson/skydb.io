#ifndef _bandicoot_h
#define _bandicoot_h

void bandicoot_init();

#endif