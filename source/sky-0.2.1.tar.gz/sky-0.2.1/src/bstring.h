#ifndef _bstring_h
#define _bstring_h

#include "bstr/bstrlib.h"
#include "bstr/bstraux.h"

#endif
