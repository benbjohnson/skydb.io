#ifndef _sky_bstring_h
#define _sky_bstring_h

#include "inttypes.h"
#include "bstr/bstrlib.h"
#include "bstr/bstraux.h"

uint32_t sky_bstring_fnv1a(bstring str);

#endif
